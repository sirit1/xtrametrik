# Cómo cargar AILock en Chrome o Edge

Descomprima este archivo. En la carpeta que queda tiene que estar manifest.json.
En Chrome o Edge escriba chrome://extensions (o edge://extensions), active el
modo de desarrollador y elija Cargar descomprimida. Señale esa carpeta, no un
archivo de dentro. Debe aparecer AILock de Xtrametrik.

En las opciones declare el nombre de la empresa, el correo del propietario y,
si lo desea, hasta veinte palabras propias. En Probar, una clave de servicio
no debe salir; el registro anota el hecho y no el valor.

Con la extensión activa, el mismo criterio rige en ChatGPT, Claude, Gemini,
Copilot, Perplexity y Grok. El dato crudo no se guarda.

La casa: alejandro.sirit@xtrametrik.com
