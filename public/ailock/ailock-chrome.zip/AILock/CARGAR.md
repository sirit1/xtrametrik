# Cómo cargar AILock en Chrome o Edge

Este es el corte del piloto. Aún no está en la tienda de Chrome y Google Workspace no puede imponerlo. Se carga a mano, en modo de desarrollador, con quien administra el navegador.

El paquete y esta carta viven en https://www.xtrametrik.com/piloto. Descomprima el archivo y quédese con la carpeta `extension`. En su raíz tiene que estar `manifest.json`. Si el navegador se queja de que no lo encuentra, se ha elegido un nivel de más o de menos.

En Chrome o Edge escriba `chrome://extensions` (o `edge://extensions`) en la barra de direcciones, active el modo de desarrollador y elija Cargar descomprimida. Señale esa carpeta, no un archivo de dentro. Debe aparecer AILock de Xtrametrik. En las opciones se declara el nombre de la empresa, el correo del propietario y, si se desea, hasta veinte palabras propias. En Probar, una clave de servicio no debe salir; el registro anota el hecho y no el valor. A la tercera detención de un secreto o de una tarjeta, la pestaña Carta muestra el aviso, listo para abrirse en el correo.

Con la extensión activa, el mismo criterio rige en ChatGPT, Claude, Gemini, Copilot, Perplexity y Grok. El envío se detiene o se vela antes de cruzar. El dato crudo no se guarda.

Cuando exista un identificador de la tienda, Workspace e Intune podrán imponerla a la plantilla. Hoy ese identificador no existe: el corte se carga descomprimido, en un piloto, no como producto de catálogo.

La casa: alejandro.sirit@xtrametrik.com
