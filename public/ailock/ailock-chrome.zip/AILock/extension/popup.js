function openTab(hash) {
  const url = chrome.runtime.getURL("options.html" + hash);
  chrome.tabs.create({ url });
}
document.getElementById("probar").onclick = () => openTab("#probar");
document.getElementById("carta").onclick = () => openTab("#carta");
document.getElementById("registro").onclick = () => openTab("#registro");
document.getElementById("casa").onclick = () => openTab("#casa");
