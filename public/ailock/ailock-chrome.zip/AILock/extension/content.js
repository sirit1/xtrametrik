(function () {
  const detector = globalThis.AILockDetector;
  if (!detector) return;

  let policy = {
    block: ["secreto", "tarjeta"],
    redact: ["iban", "email", "telefono", "id", "cliente"],
    tenantWords: [],
  };

  chrome.runtime.sendMessage({ type: "GET_POLICY" }, (res) => {
    if (res && res.ok) policy = res.policy;
  });

  const HOSTS = {
    "chatgpt.com": "chatgpt.com",
    "chat.openai.com": "chatgpt.com",
    "claude.ai": "claude.ai",
    "gemini.google.com": "gemini.google.com",
    "copilot.microsoft.com": "copilot.microsoft.com",
    "www.perplexity.ai": "perplexity.ai",
    "perplexity.ai": "perplexity.ai",
    "grok.com": "grok.com",
    "grok.x.ai": "grok.com",
  };
  const dest = HOSTS[location.hostname] || location.hostname;

  const LABELS = {
    secreto: "una clave o un secreto técnico",
    tarjeta: "un número de tarjeta",
    iban: "una cuenta bancaria",
    email: "un correo electrónico",
    telefono: "un teléfono",
    id: "un documento de identidad",
    cliente: "un nombre de cliente o de proyecto de la casa",
  };

  function banner(action, findings) {
    const old = document.getElementById("ailock-banner");
    if (old) old.remove();
    const seen = findings.map((f) => LABELS[f.category] || f.category).join(", ");
    let copy = "";
    if (action === "block") {
      copy = seen
        ? "AILock ha detenido este envío porque contenía " + seen + ". El asistente no lo ha recibido."
        : "AILock ha detenido este envío por política de la empresa.";
    } else if (action === "redact") {
      copy = "AILock ha velado " + seen + " y ha dejado pasar el resto. El modelo no ve el dato original.";
    }
    if (!copy) return;
    const el = document.createElement("div");
    el.id = "ailock-banner";
    el.setAttribute("role", "status");
    el.textContent = copy;
    el.style.cssText =
      "position:fixed;z-index:2147483647;left:16px;right:16px;bottom:16px;padding:14px 18px;" +
      "font:15px/1.5 'IBM Plex Sans',system-ui,sans-serif;color:#1a1403;background:#f4c542;border-radius:10px;" +
      "box-shadow:0 8px 24px rgba(0,0,0,.28)";
    document.documentElement.appendChild(el);
    setTimeout(() => el.remove(), 8000);
  }

  function inspectAndMaybeRewrite(textarea, raw) {
    const result = detector.scan(raw, policy);
    chrome.runtime.sendMessage({
      type: "LOG_EVENT",
      dest,
      action: result.action,
      findings: result.findings,
    });
    if (result.action === "block") {
      banner("block", result.findings);
      return { proceed: false };
    }
    if (result.action === "redact") {
      setValue(textarea, result.redacted);
      banner("redact", result.findings);
      return { proceed: true, text: result.redacted };
    }
    return { proceed: true, text: raw };
  }

  function setValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(el, value);
    else el.textContent = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function getComposer() {
    return (
      document.querySelector("#prompt-textarea") ||
      document.querySelector('div[contenteditable="true"]#prompt-textarea') ||
      document.querySelector('div[contenteditable="true"][data-placeholder]') ||
      document.querySelector("fieldset textarea") ||
      document.querySelector("textarea") ||
      document.querySelector('div[contenteditable="true"]')
    );
  }

  function readText(el) {
    if (!el) return "";
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") return el.value || "";
    return el.innerText || el.textContent || "";
  }

  function isSendControl(t) {
    if (!t) return false;
    const el = t.closest ? t.closest("button,[data-testid],[aria-label]") : t;
    if (!el) return false;
    const label = ((el.getAttribute("aria-label") || "") + " " + (el.getAttribute("data-testid") || "")).toLowerCase();
    if (label.includes("send") || label.includes("enviar") || label.includes("composer-submit")) return true;
    if (el.tagName === "BUTTON" && /send|enviar|submit/i.test(el.textContent || "")) return true;
    return false;
  }

  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key !== "Enter" || e.shiftKey) return;
      const composer = getComposer();
      if (!composer) return;
      if (!composer.contains(e.target) && e.target !== composer) return;
      const raw = readText(composer).trim();
      if (!raw) return;
      const r = inspectAndMaybeRewrite(composer, raw);
      if (!r.proceed) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );

  document.addEventListener(
    "click",
    (e) => {
      if (!isSendControl(e.target)) return;
      const composer = getComposer();
      if (!composer) return;
      const raw = readText(composer).trim();
      if (!raw) return;
      const r = inspectAndMaybeRewrite(composer, raw);
      if (!r.proceed) {
        e.preventDefault();
        e.stopPropagation();
      }
    },
    true,
  );
})();
