const DEFAULT_POLICY = {
  block: ["secreto", "tarjeta"],
  redact: ["iban", "email", "telefono", "id", "cliente"],
  tenantWords: [],
  retentionDays: 90,
};

const DEFAULT_HOUSE = {
  company: "",
  ownerEmail: "",
};

const DESTINATIONS = {
  "chatgpt.com": "chatgpt.com",
  "chat.openai.com": "chatgpt.com",
  "claude.ai": "claude.ai",
  "gemini.google.com": "gemini.google.com",
  "copilot.microsoft.com": "copilot.microsoft.com",
  "www.perplexity.ai": "perplexity.ai",
  "perplexity.ai": "perplexity.ai",
  "grok.com": "grok.com",
  "grok.x.ai": "grok.com",
};

const DAY = 24 * 60 * 60 * 1000;

const CATEGORY_LABEL = {
  secreto: "una clave o un secreto técnico",
  tarjeta: "un número de tarjeta",
  iban: "una cuenta bancaria",
  email: "un correo electrónico",
  telefono: "un teléfono",
  id: "un documento de identidad",
  cliente: "un nombre de cliente o de proyecto de la casa",
};

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(["policy", "log", "house", "notices"]);
  if (!cur.policy) await chrome.storage.local.set({ policy: DEFAULT_POLICY });
  if (!cur.log) await chrome.storage.local.set({ log: [] });
  if (!cur.house) await chrome.storage.local.set({ house: DEFAULT_HOUSE });
  if (!cur.notices) await chrome.storage.local.set({ notices: [] });
  chrome.alarms.create("ailock-prune", { periodInMinutes: 60 * 12 });
});

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "ailock-prune") prune();
});

async function prune() {
  const { policy = DEFAULT_POLICY, log = [] } = await chrome.storage.local.get(["policy", "log"]);
  const days = policy.retentionDays || 90;
  const cut = Date.now() - days * DAY;
  const next = log.filter((e) => e.ts >= cut);
  if (next.length !== log.length) await chrome.storage.local.set({ log: next });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender).then(sendResponse).catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true;
});

async function handle(msg, sender) {
  if (msg.type === "GET_POLICY") {
    const { policy = DEFAULT_POLICY } = await chrome.storage.local.get("policy");
    return { ok: true, policy };
  }
  if (msg.type === "SET_POLICY") {
    const words = (msg.policy.tenantWords || [])
      .map((w) => String(w).trim())
      .filter(Boolean)
      .slice(0, 20);
    const policy = { ...DEFAULT_POLICY, ...msg.policy, tenantWords: words };
    await chrome.storage.local.set({ policy });
    return { ok: true, policy };
  }
  if (msg.type === "GET_HOUSE") {
    const { house = DEFAULT_HOUSE } = await chrome.storage.local.get("house");
    return { ok: true, house };
  }
  if (msg.type === "SET_HOUSE") {
    const house = {
      company: String(msg.house.company || "").trim().slice(0, 80),
      ownerEmail: String(msg.house.ownerEmail || "").trim().slice(0, 120),
    };
    await chrome.storage.local.set({ house });
    return { ok: true, house };
  }
  if (msg.type === "LOG_EVENT") {
    const dest = normalizeDest(msg.dest || hostFrom(sender));
    const entry = {
      id: crypto.randomUUID(),
      ts: Date.now(),
      dest,
      action: msg.action,
      categories: (msg.findings || []).map((f) => f.category),
      counts: (msg.findings || []).map((f) => ({ category: f.category, count: f.count })),
      alertOwner: false,
    };
    const { log = [], notices = [], house = DEFAULT_HOUSE } = await chrome.storage.local.get([
      "log",
      "notices",
      "house",
    ]);
    const lastNoticeTs = notices[0]?.ts ?? 0;
    const recentBlocks = log.filter(
      (e) => e.action === "block" && e.ts > lastNoticeTs && Date.now() - e.ts < DAY,
    );
    if (entry.action === "block" && recentBlocks.length + 1 >= 3) {
      entry.alertOwner = true;
      const cluster = [...recentBlocks, entry];
      notices.unshift(
        composeOwnerNotice({
          to: house.ownerEmail || "propietario",
          company: house.company || "la empresa",
          dests: cluster.map((e) => e.dest),
          categories: cluster.flatMap((e) => e.categories),
          attempts: cluster.length,
        }),
      );
    }
    log.unshift(entry);
    await chrome.storage.local.set({ log: log.slice(0, 5000), notices: notices.slice(0, 50) });
    return { ok: true, entry, notice: notices[0] || null };
  }
  if (msg.type === "GET_LOG") {
    const { log = [] } = await chrome.storage.local.get("log");
    return { ok: true, log };
  }
  if (msg.type === "GET_NOTICES") {
    const { notices = [] } = await chrome.storage.local.get("notices");
    return { ok: true, notices };
  }
  if (msg.type === "CLEAR_LOG") {
    await chrome.storage.local.set({ log: [], notices: [] });
    return { ok: true };
  }
  return { ok: false, error: "unknown" };
}

function hostFrom(sender) {
  try {
    return new URL(sender.tab.url).hostname;
  } catch {
    return "local";
  }
}

function normalizeDest(h) {
  return DESTINATIONS[h] || h || "local";
}

function unique(xs) {
  return [...new Set(xs)];
}

function composeOwnerNotice(input) {
  const when = new Date();
  const day = when.toLocaleDateString("es-ES", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const destList = unique(input.dests).join(", ");
  const kinds = unique(input.categories.map((c) => CATEGORY_LABEL[c] || c)).join("; ");
  const subject = `AILock · ${input.company} · intento reiterado de sacar información sensible`;
  const body = [
    `A la atención de quien responde por ${input.company},`,
    ``,
    `Le escribo en nombre de AILock, el candado que Xtrametrik mantiene sobre los envíos de su casa hacia asistentes públicos.`,
    ``,
    `En el transcurso de ${day} se han registrado ${input.attempts} intentos de enviar un secreto técnico o un medio de pago hacia ${destList}. El candado ha detenido cada uno de ellos. El contenido original no se conserva ni viaja en este aviso: solo queda constancia de que el intento existió, de su hora y de la clase de dato implicada (${kinds}).`,
    ``,
    `Esta carta no acusa a persona alguna. Describe un hábito de riesgo. El registro de la jornada —sin el texto crudo— puede entregarse a su abogado o a su auditor si llega una reclamación.`,
    ``,
    `Si el trabajo exige un modelo, el cauce aprobado de la empresa es el que debe usarse, no la cuenta personal de un asistente público.`,
    ``,
    `Quedo a su disposición.`,
    ``,
    `AILock de Xtrametrik`,
    `Aviso automático · no incluye el dato interceptado`,
  ].join("\n");
  return {
    id: crypto.randomUUID(),
    ts: when.getTime(),
    to: input.to,
    company: input.company,
    subject,
    body,
    dests: unique(input.dests),
    categories: unique(input.categories),
    attempts: input.attempts,
  };
}
