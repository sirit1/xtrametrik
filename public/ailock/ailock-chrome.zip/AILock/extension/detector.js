/**
 * AILock detector — same engine for Probar, ChatGPT and Claude.
 * Never returns raw matched text to the log. Only category + action.
 */
(function (root) {
  const CARD = /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b/g;
  const CARD_SPACED = /\b(?:\d[ -]*?){13,19}\b/g;
  const SECRET = new RegExp(
    [
      "\\bsk-[A-Za-z0-9_-]{10,}",
      "\\bsk-proj-[A-Za-z0-9_-]{10,}",
      "\\bsk-ant-[A-Za-z0-9_-]{10,}",
      "\\bsk_live_[A-Za-z0-9]{16,}",
      "\\bxai-[A-Za-z0-9]{20,}",
      "\\bghp_[A-Za-z0-9]{20,}",
      "\\bgithub_pat_[A-Za-z0-9_]{20,}",
      "\\bxox[baprs]-[A-Za-z0-9-]{10,}",
      "\\bAKIA[0-9A-Z]{16}\\b",
      "\\beyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+",
      "-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
      "\\b(?:api[_-]?key|secret[_-]?key|access[_-]?token|bearer)\\s*[:=]\\s*['\\\"][^'\\\"]{8,}['\\\"]",
    ].join("|"),
    "gi"
  );
  const EMAIL = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
  const PHONE =
    /(?:\+\d{1,3}[\s.-]*(?:\(?\d{2,4}\)?[\s.-]*)?\d{3}[\s.-]\d{3}[\s.-]?\d{3,4}\b|\b\d{2,4}[\s.-]\d{3}[\s.-]\d{3,4}\b)/g;
  const ID_LIKE = /\b(?:CIF|NIF|NIE|DNI|RFC|CUIT|RUT|SSN)[\s:#-]*[A-Z0-9-]{5,}\b/gi;
  const IBAN = /\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/g;

  function luhnOk(num) {
    const d = num.replace(/\D/g, "");
    if (d.length < 13 || d.length > 19) return false;
    let sum = 0;
    let alt = false;
    for (let i = d.length - 1; i >= 0; i--) {
      let n = parseInt(d[i], 10);
      if (alt) {
        n *= 2;
        if (n > 9) n -= 9;
      }
      sum += n;
      alt = !alt;
    }
    return sum % 10 === 0;
  }

  function ibanOk(raw) {
    const s = raw.replace(/\s+/g, "").toUpperCase();
    if (s.length < 15 || s.length > 34) return false;
    const rearr = s.slice(4) + s.slice(0, 4);
    let expanded = "";
    for (const ch of rearr) {
      expanded += /[A-Z]/.test(ch) ? String(ch.charCodeAt(0) - 55) : ch;
    }
    let rem = 0;
    for (const ch of expanded) rem = (rem * 10 + Number(ch)) % 97;
    return rem === 1;
  }

  function escapeRe(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function findCards(text) {
    const hits = [];
    const raw = text.match(CARD_SPACED) || [];
    for (const m of raw) {
      if (luhnOk(m)) hits.push(m);
    }
    return hits;
  }

  function scan(text, policy) {
    const findings = [];
    if (!text || typeof text !== "string") {
      return { action: "allow", findings: [], redacted: text || "" };
    }

    const secrets = text.match(SECRET) || [];
    if (secrets.length) findings.push({ category: "secreto", count: secrets.length });

    const cards = findCards(text);
    if (cards.length) findings.push({ category: "tarjeta", count: cards.length });

    const ibans = (text.match(IBAN) || []).filter(ibanOk);
    if (ibans.length) findings.push({ category: "iban", count: ibans.length });

    const emails = (text.match(EMAIL) || []).filter((e) => !/@(example|ejemplo|test|invalid)\./i.test(e));
    if (emails.length) findings.push({ category: "email", count: emails.length });

    const phones = (text.match(PHONE) || []).filter((p) => p.replace(/\D/g, "").length >= 8);
    if (phones.length) findings.push({ category: "telefono", count: phones.length });

    const ids = text.match(ID_LIKE) || [];
    if (ids.length) findings.push({ category: "id", count: ids.length });

    const words = (policy && policy.tenantWords) || [];
    const tenantHits = [];
    for (const w of words) {
      const t = (w || "").trim();
      if (t.length < 3) continue;
      const re = new RegExp("\\b" + escapeRe(t) + "\\b", "i");
      if (re.test(text)) tenantHits.push(t);
    }
    if (tenantHits.length) findings.push({ category: "cliente", count: tenantHits.length });

    const blockCats = new Set((policy && policy.block) || ["secreto", "tarjeta"]);
    const redactCats = new Set((policy && policy.redact) || ["iban", "email", "telefono", "id", "cliente"]);

    const cats = findings.map((f) => f.category);
    const mustBlock = cats.some((c) => blockCats.has(c));
    const mustRedact = !mustBlock && cats.some((c) => redactCats.has(c));

    let redacted = text;
    if (mustBlock || mustRedact) {
      redacted = applyRedact(text, { secrets, cards, ibans, emails, phones, ids, tenantHits });
    }

    return {
      action: mustBlock ? "block" : mustRedact ? "redact" : "allow",
      findings,
      redacted,
    };
  }

  function applyRedact(text, hits) {
    let out = text;
    const mask = (s, label) => "«" + label + "»";
    for (const s of hits.secrets || []) out = out.split(s).join(mask(s, "SECRETO"));
    for (const s of hits.cards || []) out = out.split(s).join(mask(s, "TARJETA"));
    for (const s of hits.ibans || []) out = out.split(s).join(mask(s, "IBAN"));
    for (const s of hits.emails || []) out = out.split(s).join(mask(s, "CORREO"));
    for (const s of hits.phones || []) out = out.split(s).join(mask(s, "TELEFONO"));
    for (const s of hits.ids || []) out = out.split(s).join(mask(s, "ID"));
    for (const s of hits.tenantHits || []) {
      const re = new RegExp("\\b" + escapeRe(s) + "\\b", "gi");
      out = out.replace(re, "«CLIENTE»");
    }
    return out;
  }

  const api = { scan, applyRedact };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.AILockDetector = api;
})(typeof globalThis !== "undefined" ? globalThis : self);
