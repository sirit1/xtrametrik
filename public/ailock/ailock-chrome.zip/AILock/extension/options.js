const tabs = document.querySelectorAll("nav button");
const sections = document.querySelectorAll("section");

function show(id) {
  tabs.forEach((b) => b.classList.toggle("on", b.dataset.tab === id));
  sections.forEach((s) => s.classList.toggle("on", s.id === id));
  history.replaceState(null, "", "#" + id);
}

tabs.forEach((b) => b.addEventListener("click", () => show(b.dataset.tab)));
const initial = (location.hash || "#probar").slice(1);
if (["probar", "carta", "registro", "casa"].includes(initial)) show(initial);

document.getElementById("fill-secret").onclick = () => {
  document.getElementById("sample").value =
    "Redacte un correo de cobro y, para autenticar la pasarela, use esta clave sk-proj-ABCDEFghijk1234567890. No la pierda.";
};
document.getElementById("fill-pii").onclick = () => {
  document.getElementById("sample").value =
    "Prepare un recordatorio de cobro para Cliente Delta. Puede escribir a ana.perez@cliente.com o llamar al +34 612 345 678.";
};
document.getElementById("fill-ok").onclick = () => {
  document.getElementById("sample").value =
    "Resuma, en un tono sobrio, las ventajas de un sistema de clientes para una empresa de doce personas.";
};

document.getElementById("review").onclick = async () => {
  const text = document.getElementById("sample").value;
  const { policy } = await chrome.runtime.sendMessage({ type: "GET_POLICY" });
  const result = AILockDetector.scan(text, policy);
  await chrome.runtime.sendMessage({
    type: "LOG_EVENT",
    dest: "local",
    action: result.action,
    findings: result.findings,
  });
  const out = document.getElementById("out");
  out.hidden = false;
  out.className = "result " + result.action;
  const cats = result.findings.map((f) => f.category).join(", ") || "ninguna";
  const label =
    result.action === "block"
      ? "El mensaje no salió. El candado lo detuvo antes de que cruzara la puerta."
      : result.action === "redact"
        ? "El mensaje pudo salir, pero lo delicado viajó tapado."
        : "El mensaje habría salido entero. No había dato sensible.";
  out.innerHTML =
    "<strong>" +
    label +
    "</strong><p>Clase: " +
    cats +
    "</p>" +
    (result.action === "redact"
      ? "<pre style='white-space:pre-wrap;margin:8px 0 0'>" + escapeHtml(result.redacted) + "</pre>"
      : "");
  loadLog();
  loadLetter();
};

function escapeHtml(s) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&", "<": "<", ">": ">" }[c]));
}

async function loadLog() {
  const { log } = await chrome.runtime.sendMessage({ type: "GET_LOG" });
  const tb = document.getElementById("rows");
  tb.innerHTML = (log || [])
    .map((e) => {
      const when = new Date(e.ts).toLocaleString("es-ES");
      const flag = e.alertOwner ? " · carta" : "";
      return `<tr><td>${when}</td><td>${e.dest}</td><td>${e.action}${flag}</td><td>${(e.categories || []).join(", ")}</td></tr>`;
    })
    .join("");
}

async function loadLetter() {
  const { notices } = await chrome.runtime.sendMessage({ type: "GET_NOTICES" });
  const box = document.getElementById("letter-box");
  const n = (notices || [])[0];
  if (!n) {
    box.innerHTML =
      "<p class='hint'>Aún no hay carta. Intente tres veces una clave de servicio: al tercero se redacta el aviso.</p>";
    return;
  }
  const mailto =
    "mailto:" +
    encodeURIComponent(n.to) +
    "?subject=" +
    encodeURIComponent(n.subject) +
    "&body=" +
    encodeURIComponent(n.body);
  const paras = n.body
    .split("\n\n")
    .map((p) => "<p>" + escapeHtml(p) + "</p>")
    .join("");
  box.innerHTML =
    "<article class='letter'><p class='hint'>Para " +
    escapeHtml(n.to) +
    "</p><h3>" +
    escapeHtml(n.subject) +
    "</h3>" +
    paras +
    "<div class='row'><a class='act' style='display:inline-flex;align-items:center;text-decoration:none' href='" +
    mailto +
    "'>Abrir en el correo</a><button class='ghost' id='copy-letter'>Copiar la carta</button></div></article>";
  const copy = document.getElementById("copy-letter");
  if (copy) {
    copy.onclick = async () => {
      await navigator.clipboard.writeText("Para: " + n.to + "\nAsunto: " + n.subject + "\n\n" + n.body);
      copy.textContent = "Copiada";
    };
  }
}

document.getElementById("refresh").onclick = () => {
  loadLog();
  loadLetter();
};
document.getElementById("clear").onclick = async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_LOG" });
  loadLog();
  loadLetter();
};
document.getElementById("export").onclick = async () => {
  const { log } = await chrome.runtime.sendMessage({ type: "GET_LOG" });
  const header = "fecha,destino,resolucion,categorias,carta";
  const lines = (log || []).map((e) =>
    [new Date(e.ts).toISOString(), e.dest, e.action, (e.categories || []).join("|"), e.alertOwner ? "si" : "no"].join(
      ",",
    ),
  );
  const blob = new Blob([header + "\n" + lines.join("\n")], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "ailock-registro.csv";
  a.click();
};

async function loadHouse() {
  const { policy } = await chrome.runtime.sendMessage({ type: "GET_POLICY" });
  const { house } = await chrome.runtime.sendMessage({ type: "GET_HOUSE" });
  document.getElementById("words").value = (policy.tenantWords || []).join("\n");
  document.getElementById("company").value = (house && house.company) || "";
  document.getElementById("owner").value = (house && house.ownerEmail) || "";
}
document.getElementById("save").onclick = async () => {
  const tenantWords = document
    .getElementById("words")
    .value.split(/\n+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 20);
  await chrome.runtime.sendMessage({ type: "SET_POLICY", policy: { tenantWords } });
  await chrome.runtime.sendMessage({
    type: "SET_HOUSE",
    house: {
      company: document.getElementById("company").value,
      ownerEmail: document.getElementById("owner").value,
    },
  });
  document.getElementById("saved").textContent = "Casa conservada. El criterio ya rige en este navegador.";
};

loadLog();
loadHouse();
loadLetter();
